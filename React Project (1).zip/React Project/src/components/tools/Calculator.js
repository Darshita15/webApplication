import React from 'react';
import { ToolsDiv } from '../pages/Tools';
import { Container, Card } from 'react-bootstrap';
import Header, { Footer, Navbar } from '../Theme';

function calc(e)
{
    let display = document.getElementById("inputs");
    
    switch (e.target.value) 
    {
        case "C":
            display.innerText = "";
            break;
        case "=":
            try {
                display.innerText = eval(display.innerText);
            } catch {
                display.innerText = "Error";
            }
            break;
    
        default:
            display.innerText += e.target.innerText;
    }
}

const Calculator = () => {
    
    return (

        <div>  
            <Navbar />

            <div className='right-container'>
                <Header headingText='Calculator' />
                
                <Container className="d-flex justify-content-center">
                    <ToolsDiv />
                </Container>
                
                <Container className="d-flex justify-content-center"
                    style={{ minHeight: "407px", paddingBottom: "25px" }}>

                    <Card>
                      <Card.Body>
                        <div>
                            <div type="text" id="inputs"></div>
                        </div>
                        <div className="buttons">
                            <div className="keypadj">
                                <div className="keypadi">
                                    <button className="button" value='+' onClick={(event) => calc(event)}>+</button>
                                    <button className="button" value='-' onClick={(event) => calc(event)}>-</button>
                                    <button className="button" value='*' onClick={(event) => calc(event)}>*</button>
                                    <button className="button" value='/' onClick={(event) => calc(event)}>/</button>
                                </div>

                                <div className="keypadi">
                                    <button className="button" value='7' onClick={(event) => calc(event)}>7</button>
                                    <button className="button" value='4' onClick={(event) => calc(event)}>4</button>
                                    <button className="button" value='1' onClick={(event) => calc(event)}>1</button>
                                    <button className="button" value='0' onClick={(event) => calc(event)}>0</button>
                                </div>

                                <div className="keypadi">
                                    <button className="button" value='8' onClick={(event) => calc(event)}>8</button>
                                    <button className="button" value='5' onClick={(event) => calc(event)}>5</button>
                                    <button className="button" value='2' onClick={(event) => calc(event)}>2</button>
                                    <button className="button" value='.' onClick={(event) => calc(event)}>.</button>
                                </div>

                                <div className="keypadi">
                                    <button className="button" value='9' onClick={(event) => calc(event)}>9</button>
                                    <button className="button" value='6' onClick={(event) => calc(event)}>6</button>
                                    <button className="button" value='3' onClick={(event) => calc(event)}>3</button>
                                    <button className="button" value='C' onClick={(event) => calc(event)} id="clear">C</button>
                                </div>

                                <div className="keypadi">
                                    <button id="equal" className="button" value='=' onClick={(event) => calc(event)}>=</button>
                                </div>
                            </div>
                        </div>
                      </Card.Body>
                    </Card>

                    
                </Container>

                <Footer />
            </div>
        </div>
    );
};

export default Calculator;